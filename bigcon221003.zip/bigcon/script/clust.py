
import pandas as pd
import numpy as np
from glob import glob
import seaborn as sns
import matplotlib.pyplot as plt
import geopandas as gpd
from sklearn.cluster import KMeans



# In[4]:


import warnings
warnings.filterwarnings(action='ignore')


# In[55]:
path = 'C:/bigcon/script'
import sys
sys.path.append(path)
from k_table import out, map_, df_res, df_act, df_res_act

#%%
path = 'C:/bigcon/'
col_nm = out.columns

sample = np.array(out.copy()).astype(float)

def elbow(n_iter,df):
    sse = []
    for i in range(1,n_iter + 1):
        k_means = KMeans(init="k-means++", n_clusters=i, n_init=20)
        k_means.fit(df)
        sse.append(k_means.inertia_)
        
        
    plt.plot(range(1,n_iter + 1), sse, marker = 'o')
    plt.xlabel('클러스터 갯수')
    plt.ylabel('SSE')
    plt.savefig(path + 'output/plot/k_means_elbow.png')
    plt.show
    
elbow(20,sample)

# In[32]:


k_means = KMeans(init="k-means++", n_clusters=7, n_init=20)
k_means.fit(sample)


# In[33]:
### 다양한 기법을 사용하고 교집합 시킬건지, 다양한 변수를 각각 클러스트링 하고 교집합 시킬건지 고민해봐야됨

k_means_labels = k_means.labels_

map_['label'] = k_means_labels.astype(str)

k_means_cluster_centers = pd.DataFrame(k_means.cluster_centers_).copy()

k_means_cluster_centers.columns = ['앱 실행 수', '기존 전기차 충전소 수', '아파트 총 세대수']


# mapped.plot(column = 'label', cmap = 'tab10', legend = True,figsize = (10,10))

# for idx, row in mapped.iterrows():
#     plt.annotate(s=row['adng_nm'], xy=row['coords'], horizontalalignment='center', color= 'k')

## 군집평균 스케일링 후 스코어 적용

from sklearn.preprocessing import MinMaxScaler

w_vector = np.array([1.5,-0.5,1.3])



min_max_scaler = MinMaxScaler()
x_scaled = min_max_scaler.fit_transform(k_means_cluster_centers)
        
x_scaled = pd.DataFrame(x_scaled)

x_scaled['score'] = (np.array(x_scaled) * w_vector).sum(axis = 1)

k_means_cluster_centers

k_means_labels
map_.loc[map_['label'] == '1','adng_nm'] 

#%%

# agglomerative clustering
from numpy import unique
from numpy import where
from sklearn.datasets import make_classification
from sklearn.cluster import AgglomerativeClustering
from matplotlib import pyplot

# define dataset
X = sample# define the model
model = AgglomerativeClustering(n_clusters=6)

# fit model and predict clusters
yhat = model.fit_predict(X)
# retrieve unique clusters
clusters = unique(yhat)
# create scatter plot for samples from each cluster
for cluster in clusters:
	# get row indexes for samples with this cluster
	row_ix = where(yhat == cluster)
	# create scatter of these samples
	pyplot.scatter(X[row_ix, 0], X[row_ix, 1])
# show the plot
pyplot.show()

#%%
# affinity propagation clustering
from numpy import unique
from numpy import where
from sklearn.datasets import make_classification
from sklearn.cluster import AffinityPropagation
from matplotlib import pyplot
# define dataset
# define the model
model = AffinityPropagation(damping=0.9)
# fit the model
model.fit(X)
# assign a cluster to each example
yhat = model.predict(X)
# retrieve unique clusters
clusters = unique(yhat)

# create scatter plot for samples from each cluster
for cluster in clusters:
	# get row indexes for samples with this cluster
	row_ix = where(yhat == cluster)
	# create scatter of these samples
	pyplot.scatter(X[row_ix, 0], X[row_ix, 1])
# show the plot
pyplot.show()
#%%
# agglomerative clustering
from numpy import unique
from numpy import where
from sklearn.datasets import make_classification
from sklearn.cluster import AgglomerativeClustering
from matplotlib import pyplot
# define dataset
X, _ = make_classification(n_samples=1000, n_features=2, n_informative=2, n_redundant=0, n_clusters_per_class=1, random_state=4)
# define the model
model = AgglomerativeClustering(n_clusters=2)
# fit model and predict clusters
yhat = model.fit_predict(X)
# retrieve unique clusters
clusters = unique(yhat)
# create scatter plot for samples from each cluster
for cluster in clusters:
	# get row indexes for samples with this cluster
	row_ix = where(yhat == cluster)
	# create scatter of these samples
	pyplot.scatter(X[row_ix, 0], X[row_ix, 1])
# show the plot
pyplot.show()
#%%
# birch clustering
from numpy import unique
from numpy import where
from sklearn.datasets import make_classification
from sklearn.cluster import Birch
from matplotlib import pyplot
# define dataset
# define the model
model = Birch(threshold=0.01, n_clusters=6)
# fit the model
model.fit(X)
# assign a cluster to each example
yhat = model.predict(X)
# retrieve unique clusters
clusters = unique(yhat)
# create scatter plot for samples from each cluster
for cluster in clusters:
	# get row indexes for samples with this cluster
	row_ix = where(yhat == cluster)
	# create scatter of these samples
	pyplot.scatter(X[row_ix, 0], X[row_ix, 1])
# show the plot
pyplot.show()
#%%
# dbscan clustering
from numpy import unique
from numpy import where
from sklearn.datasets import make_classification
from sklearn.cluster import DBSCAN
from matplotlib import pyplot
# define dataset
X, _ = make_classification(n_samples=1000, n_features=2, n_informative=2, n_redundant=0, n_clusters_per_class=1, random_state=4)
# define the model
model = DBSCAN(eps=0.30, min_samples=9)
# fit model and predict clusters
yhat = model.fit_predict(X)
# retrieve unique clusters
clusters = unique(yhat)
# create scatter plot for samples from each cluster
for cluster in clusters:
	# get row indexes for samples with this cluster
	row_ix = where(yhat == cluster)
	# create scatter of these samples
	pyplot.scatter(X[row_ix, 0], X[row_ix, 1])
# show the plot
pyplot.show()
#%%

